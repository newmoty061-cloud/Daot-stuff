package dev.daotlimbs.mixin.client;

import dev.daotlimbs.Limb;
import dev.daotlimbs.client.ClientLimbState;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.PlayerEntityRenderer;
import net.minecraft.client.util.math.MatrixStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** First-person: don't draw an arm you no longer have. */
@Mixin(PlayerEntityRenderer.class)
public abstract class PlayerEntityRendererMixin {
    @Inject(method = "renderRightArm", at = @At("HEAD"), cancellable = true)
    private void daotlimbs$noRightArm(MatrixStack m, VertexConsumerProvider v, int light, AbstractClientPlayerEntity p, CallbackInfo ci) {
        if ((ClientLimbState.get(p.getId()) & Limb.RIGHT_ARM.bit()) != 0) ci.cancel();
    }

    @Inject(method = "renderLeftArm", at = @At("HEAD"), cancellable = true)
    private void daotlimbs$noLeftArm(MatrixStack m, VertexConsumerProvider v, int light, AbstractClientPlayerEntity p, CallbackInfo ci) {
        if ((ClientLimbState.get(p.getId()) & Limb.LEFT_ARM.bit()) != 0) ci.cancel();
    }
}
