package dev.daotlimbs.client;

import dev.daotlimbs.scout.ScoutEntity;
import net.minecraft.client.render.entity.BipedEntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.model.EntityModelLayers;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.util.Identifier;

/** Scouts use the normal player model with their own skin. */
public class ScoutEntityRenderer extends BipedEntityRenderer<ScoutEntity, PlayerEntityModel<ScoutEntity>> {
    public ScoutEntityRenderer(EntityRendererFactory.Context ctx) {
        super(ctx, new PlayerEntityModel<>(ctx.getPart(EntityModelLayers.PLAYER), false), 0.5f);
    }

    @Override
    public Identifier getTexture(ScoutEntity entity) {
        return ScoutEntity.texture(entity.getVariant());
    }
}
