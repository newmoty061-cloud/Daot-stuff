package dev.daotlimbs.client;

import dev.daotlimbs.Limb;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.feature.FeatureRenderer;
import net.minecraft.client.render.entity.feature.FeatureRendererContext;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;

/**
 * A lost eye = a black patch on the face, so the eye looks hollow. While the eye heals, the patch
 * washes away from the top downward (driven by the same grow progress the skin growth uses).
 */
public class HollowEyeFeature extends FeatureRenderer<AbstractClientPlayerEntity, PlayerEntityModel<AbstractClientPlayerEntity>> {
    private static final Identifier WHITE = Identifier.ofVanilla("textures/misc/white.png");

    public HollowEyeFeature(FeatureRendererContext<AbstractClientPlayerEntity, PlayerEntityModel<AbstractClientPlayerEntity>> context) {
        super(context);
    }

    @Override
    public void render(MatrixStack matrices, VertexConsumerProvider vertexConsumers, int light, AbstractClientPlayerEntity player,
                       float limbAngle, float limbDistance, float tickDelta, float animationProgress, float headYaw, float headPitch) {
        int id = player.getId();
        int mask = ClientLimbState.get(id);
        boolean left = (mask & Limb.LEFT_EYE.bit()) != 0;
        boolean right = (mask & Limb.RIGHT_EYE.bit()) != 0;
        if (!left && !right) return;

        int[] sp = ClientLimbState.getSpots(id);
        matrices.push();
        this.getContextModel().head.rotate(matrices);
        VertexConsumer vc = vertexConsumers.getBuffer(RenderLayer.getEntityCutoutNoCull(WHITE));
        MatrixStack.Entry entry = matrices.peek();
        if (left) quad(vc, entry, light, sp[0] / 10f, sp[1] / 10f, ClientLimbState.getGrow(id, Limb.LEFT_EYE.ordinal()));
        if (right) quad(vc, entry, light, sp[2] / 10f, sp[3] / 10f, ClientLimbState.getGrow(id, Limb.RIGHT_EYE.ordinal()));
        matrices.pop();
    }

    /** px, py = centre on the 8x8 face as the viewer sees it. erase 0..1 = how much has washed away from the top. */
    private static void quad(VertexConsumer vc, MatrixStack.Entry e, int light, float px, float py, float erase) {
        // viewer's left of the face is the player's right = model -x; model y runs downward from the top of the head at -8
        float x0 = -4f + (px - 1f), x1 = -4f + (px + 1f);
        float y1 = -8f + (py + 1f);
        float y0 = -8f + (py - 1f);
        y0 = y0 + (y1 - y0) * Math.max(0f, Math.min(1f, erase));
        if (y1 - y0 < 0.01f) return;
        float z = -4.55f;                                  // just in front of the face and the hat layer
        v(vc, e, light, x0, y0, z);
        v(vc, e, light, x0, y1, z);
        v(vc, e, light, x1, y1, z);
        v(vc, e, light, x1, y0, z);
    }

    private static void v(VertexConsumer vc, MatrixStack.Entry e, int light, float x, float y, float z) {
        vc.vertex(e, x / 16f, y / 16f, z / 16f)
                .color(0, 0, 0, 255)
                .texture(0f, 0f)
                .overlay(OverlayTexture.DEFAULT_UV)
                .light(light)
                .normal(e, 0f, 0f, -1f);
    }
}
