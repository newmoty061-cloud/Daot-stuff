package dev.daotlimbs.client;

import it.unimi.dsi.fastutil.ints.Int2IntOpenHashMap;
import it.unimi.dsi.fastutil.ints.Int2ObjectOpenHashMap;

/** Client-side copy of every visible player's limb state, keyed by entity id. */
public final class ClientLimbState {
    private ClientLimbState() {}

    private static final Int2IntOpenHashMap MASKS = new Int2IntOpenHashMap();
    /** per entity: how far each real (skin) limb has grown back, indexed by Limb ordinal. */
    private static final Int2ObjectOpenHashMap<float[]> GROW = new Int2ObjectOpenHashMap<>();

    public static int get(int entityId) { return MASKS.get(entityId); }

    public static void put(int entityId, int mask) {
        if (mask == 0) MASKS.remove(entityId);
        else MASKS.put(entityId, mask);
        float[] g = GROW.get(entityId);
        if (g != null) {
            boolean any = false;
            for (int i = 0; i < g.length; i++) {
                if ((mask & (1 << i)) == 0) g[i] = 0f;      // limb is whole again (or gone): stop scaling it
                if (g[i] > 0f) any = true;
            }
            if (!any) GROW.remove(entityId);
        }
    }

    public static void setGrow(int entityId, int limb, float progress) {
        if (limb < 0 || limb > 5) return;
        float[] g = GROW.computeIfAbsent(entityId, k -> new float[6]);
        g[limb] = progress;
    }

    public static float getGrow(int entityId, int limb) {
        float[] g = GROW.get(entityId);
        return g == null ? 0f : g[limb];
    }

    private static final Int2ObjectOpenHashMap<int[]> SPOTS = new Int2ObjectOpenHashMap<>();

    public static void setSpots(int entityId, int lx, int ly, int rx, int ry) {
        SPOTS.put(entityId, new int[]{lx, ly, rx, ry});
    }

    /** [leftX*10, leftY*10, rightX*10, rightY*10] on the 8x8 face as the viewer sees it. */
    public static int[] getSpots(int entityId) {
        int[] s = SPOTS.get(entityId);
        return s != null ? s : new int[]{60, 50, 20, 50};
    }

    public static void clear() { MASKS.clear(); GROW.clear(); SPOTS.clear(); }
}
