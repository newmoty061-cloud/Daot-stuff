package dev.daotlimbs;

import dev.daotlimbs.net.LimbNet;
import net.fabricmc.fabric.api.networking.v1.PlayerLookup;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.EntityAttribute;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.registry.tag.DamageTypeTags;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.random.Random;

import java.util.*;

/** All limb logic: losing, bleeding, effects, shifter regrowth, head death, sync. */
public final class LimbManager {
    private LimbManager() {}

    private static final String AOT_NS = "dannys-aot";

    private static final Map<UUID, Long> BLEED_UNTIL = new HashMap<>();
    private static final Map<UUID, Long> LAST_LOSS = new HashMap<>();
    private static final Map<UUID, List<Regen>> REGEN = new HashMap<>();
    private static final Set<UUID> EFFECTS_APPLIED = new HashSet<>();
    private static final Map<UUID, Integer> HEALING = new HashMap<>();
    private static final Set<UUID> SHATTERED_BY_US = new HashSet<>();
    private static final Map<UUID, Long> FALLEN_UNTIL = new HashMap<>();
    private static final Map<UUID, Integer> FALL_LEVEL = new HashMap<>();   // 2 = lying flat, 1 = pushed up onto knees

    private static final class Regen {
        final Limb.Group group;
        final int mask;
        int age;
        boolean steam = true;           // false for bandages: flesh and bone only, no steam
        Regen(Limb.Group g, int mask) { this.group = g; this.mask = mask; }
    }

    // =====================================================================================
    //  Losing
    // =====================================================================================

    /** Called for every hit on a player (or on the titan body of a shifter, with inTitan=true). */
    public static void onHurt(ServerPlayerEntity p, DamageSource src, float amount, boolean inTitan) {
        if (amount > 500f || !p.isAlive() || p.isCreative() || p.isSpectator()) return;
        long now = p.getServerWorld().getTime();
        if (now - LAST_LOSS.getOrDefault(p.getUuid(), -1000L) < LimbConfig.MIN_TICKS_BETWEEN_LOSSES) return;

        Random r = p.getRandom();
        Entity atk = src.getAttacker();
        boolean aot = atk != null && AOT_NS.equals(Registries.ENTITY_TYPE.getId(atk.getType()).getNamespace());
        boolean blade = atk instanceof LivingEntity le && isBlade(le.getMainHandStack());
        boolean explosion = src.isIn(DamageTypeTags.IS_EXPLOSION);
        boolean fall = src.isIn(DamageTypeTags.IS_FALL);

        double chance = 0;
        int pool = Limb.ALL;
        float titanMin = inTitan ? LimbConfig.TITAN_FORM_MIN : LimbConfig.TITAN_HIT_MIN;
        if (aot && amount >= titanMin) chance = LimbConfig.TITAN_HIT_CHANCE;
        else if (blade && amount >= LimbConfig.BLADE_HIT_MIN) chance = LimbConfig.BLADE_HIT_CHANCE;
        else if (explosion && amount >= LimbConfig.EXPLOSION_HIT_MIN) chance = LimbConfig.EXPLOSION_HIT_CHANCE;
        else if (fall && amount >= LimbConfig.FALL_MIN) { chance = LimbConfig.FALL_LEG_CHANCE; pool = Limb.maskOf(Limb.Group.LEG); }
        else if (amount >= LimbConfig.OTHER_HIT_MIN) chance = LimbConfig.OTHER_BIG_HIT_CHANCE;

        if (chance <= 0 || r.nextDouble() >= chance) return;

        if (aot && amount >= LimbConfig.HEAD_MIN && r.nextDouble() < LimbConfig.HEAD_CHANCE) {
            loseHead(p);
            return;
        }

        int intact = pool & ~LimbData.get(p);
        if (intact == 0) return;
        // weighted: arms 2, legs 2, eyes 1 (only groups that still have something to lose)
        int wArm = (intact & Limb.maskOf(Limb.Group.ARM)) != 0 ? 2 : 0;
        int wLeg = (intact & Limb.maskOf(Limb.Group.LEG)) != 0 ? 2 : 0;
        int wEye = (intact & Limb.maskOf(Limb.Group.EYES)) != 0 ? 1 : 0;
        int roll = r.nextInt(wArm + wLeg + wEye);
        Limb.Group g = roll < wArm ? Limb.Group.ARM : (roll < wArm + wLeg ? Limb.Group.LEG : Limb.Group.EYES);
        List<Limb> options = new ArrayList<>();
        for (Limb l : Limb.values()) if (l.group == g && (intact & l.bit()) != 0) options.add(l);
        lose(p, options.get(r.nextInt(options.size())).bit());
    }

    private static boolean isBlade(ItemStack s) {
        if (s.isEmpty()) return false;
        Identifier id = Registries.ITEM.getId(s.getItem());
        return AOT_NS.equals(id.getNamespace()) && id.getPath().contains("blade") && !id.getPath().contains("component");
    }

    /** Removes the given limbs. Returns false if nothing new was lost. */
    public static boolean lose(ServerPlayerEntity p, int bits) {
        int cur = LimbData.get(p);
        int add = bits & ~cur & Limb.ALL;
        if (add == 0) return false;

        LimbData.set(p, cur | add);

        // first eye ever lost: let the player choose where the hollow is
        if ((add & Limb.maskOf(Limb.Group.EYES)) != 0) {
            int[] sp = LimbData.spots(p);
            if (sp[4] == 0) {
                sp[4] = 1;
                LimbData.setSpots(p, sp);
                Limb first = (add & Limb.LEFT_EYE.bit()) != 0 ? Limb.LEFT_EYE : Limb.RIGHT_EYE;
                ServerPlayNetworking.send(p, new LimbNet.EyeMenuPayload(first.ordinal()));
            }
        }
        ServerWorld w = p.getServerWorld();
        long now = w.getTime();
        BLEED_UNTIL.put(p.getUuid(), now + LimbConfig.BLEED_TICKS);
        LAST_LOSS.put(p.getUuid(), now);

        Entity body = bodyOf(p);
        for (Limb l : Limb.values()) {
            if ((add & l.bit()) != 0) {
                Vec3d a = Anchors.top(body, l);
                Fx.at(w, Fx.BLOOD, a, 25, 0.25, 0.08);
                Fx.at(w, Fx.BLOOD_CHUNK, a, 12, 0.2, 0.15);
            }
        }
        w.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.ENTITY_PLAYER_HURT, SoundCategory.PLAYERS, 1.2f, 0.6f);
        w.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.BLOCK_SLIME_BLOCK_BREAK, SoundCategory.PLAYERS, 1.0f, 0.5f);

        if ((add & Limb.maskOf(Limb.Group.LEG)) != 0) {
            FALLEN_UNTIL.put(p.getUuid(), now + LimbConfig.LEG_FALL_TICKS);   // you go down
            if (Integer.bitCount((cur | add) & Limb.maskOf(Limb.Group.LEG)) >= 2 && !p.hasVehicle()) {
                // both legs gone: you topple forward onto your face
                double yawRad = Math.toRadians(p.getYaw());
                p.setVelocity(-Math.sin(yawRad) * LimbConfig.FACEPLANT_PUSH, 0.12, Math.cos(yawRad) * LimbConfig.FACEPLANT_PUSH);
                p.velocityModified = true;
                w.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.ENTITY_PLAYER_BIG_FALL, SoundCategory.PLAYERS, 1.0f, 0.7f);
                Fx.at(w, net.minecraft.particle.ParticleTypes.POOF, p.getPos(), 8, 0.3, 0.05);
            }
        }
        if ((add & Limb.RIGHT_ARM.bit()) != 0) dropHand(p, Hand.MAIN_HAND);
        if ((add & Limb.LEFT_ARM.bit()) != 0) dropHand(p, Hand.OFF_HAND);

        applyEffects(p);
        sync(p);
        p.sendMessage(Text.literal("You lost your " + Limb.describe(add) + "!").formatted(Formatting.DARK_RED), true);
        return true;
    }

    private static boolean dropHand(ServerPlayerEntity p, Hand hand) {
        ItemStack s = p.getStackInHand(hand);
        if (s.isEmpty()) return false;
        p.dropItem(s.copy(), false);
        p.setStackInHand(hand, ItemStack.EMPTY);
        return true;
    }

    /** Losing your head kills you, shifter or not. */
    public static void loseHead(ServerPlayerEntity p) {
        if (!p.isAlive() || p.isCreative() || p.isSpectator()) return;
        ServerWorld w = p.getServerWorld();
        Fx.at(w, Fx.BLOOD, Anchors.top(bodyOf(p), Limb.LEFT_EYE).add(0, 0.3, 0), 40, 0.3, 0.1);
        MinecraftServer server = w.getServer();
        server.getPlayerManager().broadcast(Text.literal(p.getName().getString() + " lost their head.").formatted(Formatting.DARK_RED), false);
        DamageSource src = p.getDamageSources().genericKill();
        p.damage(src, Float.MAX_VALUE);
        if (p.isAlive()) { p.setHealth(0f); p.onDeath(src); }
    }

    // =====================================================================================
    //  Regrowing (shifters only)
    // =====================================================================================

    /** Returns null on success, otherwise a message for the player. */
    public static String startRegrow(ServerPlayerEntity p, Limb.Group g) {
        if (!DaotBridge.isShifter(p)) return "Only titan shifters can regrow limbs.";
        int lost = LimbData.get(p) & Limb.maskOf(g);
        if (lost == 0) return "Nothing to regrow there.";
        List<Regen> list = REGEN.computeIfAbsent(p.getUuid(), k -> new ArrayList<>());
        for (Regen r : list) if (r.group == g) return "Already regrowing.";
        list.add(new Regen(g, lost));
        ServerWorld w = p.getServerWorld();
        w.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.BLOCK_FIRE_EXTINGUISH, SoundCategory.PLAYERS, 1.0f, 0.7f);
        p.sendMessage(Text.literal("Regenerating " + Limb.describe(lost) + "...").formatted(Formatting.GOLD), true);
        return null;
    }

    // ---------- hearts (shifters only, on command) ----------

    /** In titan form the "hearts" that matter are the titan's. */
    public static LivingEntity healTarget(ServerPlayerEntity p) {
        Entity t = DaotBridge.ridingTitan(p);
        return t instanceof LivingEntity le ? le : p;
    }

    public static boolean isHurt(ServerPlayerEntity p) {
        LivingEntity t = healTarget(p);
        return t.getHealth() < t.getMaxHealth() - 0.01f;
    }

    /** Returns null on success, otherwise a message for the player. */
    public static String startHeal(ServerPlayerEntity p) {
        if (!DaotBridge.isShifter(p)) return "Only titan shifters can heal on command.";
        if (!isHurt(p)) return "Your hearts are already full.";
        if (HEALING.containsKey(p.getUuid())) return "Already healing.";
        HEALING.put(p.getUuid(), 0);
        p.getServerWorld().playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.BLOCK_FIRE_EXTINGUISH, SoundCategory.PLAYERS, 1.0f, 0.7f);
        p.sendMessage(Text.literal("Healing...").formatted(Formatting.GOLD), true);
        return null;
    }

    private static void tickHeal(ServerPlayerEntity p, int age) {
        LivingEntity t = healTarget(p);
        ServerWorld w = p.getServerWorld();
        age++;
        if (age % LimbConfig.HEART_STEP_TICKS == 0) {
            LimbRules.allowHeal = true;
            try {
                t.heal(Math.max(1f, t.getMaxHealth() * LimbConfig.HEART_STEP_FRACTION));
            } finally {
                LimbRules.allowHeal = false;
            }
        }
        if (age % 3 == 0) {
            Vec3d c = new Vec3d(t.getX(), t.getY() + t.getHeight() * 0.6, t.getZ());
            if (t == p) Fx.smoke(w, c, 3, 0.3);
            else Fx.far(w, Fx.steam(), c, 4, Math.max(0.5, t.getWidth() * 0.4), 0.02);
        }
        if (t.getHealth() >= t.getMaxHealth() - 0.01f) {
            HEALING.remove(p.getUuid());
            p.sendMessage(Text.literal("Your wounds closed.").formatted(Formatting.GREEN), true);
        } else {
            HEALING.put(p.getUuid(), age);
        }
    }

    // ---------- bandage (any race; limbs only; flesh + bone, no steam) ----------

    /** Starts regrowing missing arms and legs. Returns false if there was nothing to heal. */
    public static boolean startBandage(ServerPlayerEntity p) {
        boolean any = false;
        List<Regen> list = REGEN.computeIfAbsent(p.getUuid(), k -> new ArrayList<>());
        for (Limb.Group g : new Limb.Group[]{Limb.Group.ARM, Limb.Group.LEG}) {
            int lost = LimbData.get(p) & Limb.maskOf(g);
            if (lost == 0 || regrowing(p.getUuid(), g)) continue;
            Regen r = new Regen(g, lost);
            r.steam = false;
            r.age = LimbConfig.REGEN_SMOKE;       // skip the steam-only phase: bone starts straight away
            list.add(r);
            any = true;
        }
        if (any) {
            p.getServerWorld().playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.BLOCK_WOOL_PLACE, SoundCategory.PLAYERS, 1.0f, 0.8f);
            p.sendMessage(Text.literal("Bandaged. Your limbs are mending...").formatted(Formatting.GOLD), true);
        }
        return any;
    }

    /** Instant restore (used by /daot shifter regrow and when regrowth finishes). */
    public static void restore(ServerPlayerEntity p, int bits) {
        int cur = LimbData.get(p);
        int now = cur & ~bits;
        if (now == cur) return;
        LimbData.set(p, now);
        applyEffects(p);
        sync(p);
    }

    private static boolean regrowing(UUID id, Limb.Group g) {
        List<Regen> l = REGEN.get(id);
        if (l == null) return false;
        for (Regen r : l) if (r.group == g) return true;
        return false;
    }

    // =====================================================================================
    //  Per-tick work
    // =====================================================================================

    public static void tick(MinecraftServer server) {
        LimbRules.suppressHeal = false;
        for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
            if (!p.isAlive()) continue;
            if (p.age % 10 == 0) pollHead(p);
            Integer healAge = HEALING.get(p.getUuid());
            if (healAge != null) tickHeal(p, healAge);

            int mask = LimbData.get(p);
            int level = fallLevel(p, mask);
            int prevLevel = FALL_LEVEL.getOrDefault(p.getUuid(), 0);
            if (level != prevLevel) {
                if (level == 0) FALL_LEVEL.remove(p.getUuid()); else FALL_LEVEL.put(p.getUuid(), level);
                sync(p);
                if (prevLevel == 2 && level == 1) p.sendMessage(Text.literal("Your legs push you up...").formatted(Formatting.GOLD), true);
            }
            // while flat on the ground, the legs growing back shove your body upward in little pushes
            if (level == 2 && legsRegrowing(p) && p.age % 8 == 0 && p.isOnGround()) {
                p.setVelocity(p.getVelocity().add(0.0, 0.22, 0.0));
                p.velocityModified = true;
            }
            if (mask != 0) { enforceArms(p, mask); swimPenalty(p, mask); }
            List<Regen> regs = REGEN.get(p.getUuid());
            if (mask == 0 && (regs == null || regs.isEmpty())) {
                if (EFFECTS_APPLIED.remove(p.getUuid())) applyEffects(p);
                continue;
            }
            if (p.age % 40 == 0) applyEffects(p);                 // re-applies after relog
            if (mask != 0 && p.age % 20 == 0 && (mask & Limb.maskOf(Limb.Group.EYES)) == Limb.maskOf(Limb.Group.EYES)) {
                p.addStatusEffect(new StatusEffectInstance(StatusEffects.BLINDNESS, 60, 0, false, false, false));
                Entity eyeTitan = DaotBridge.ridingTitan(p);
                if (eyeTitan != null && !DaotBridge.isTitanBlinded(eyeTitan)) DaotBridge.blindTitan(eyeTitan);
            }

            ServerWorld w = p.getServerWorld();
            Entity body = bodyOf(p);

            // bleeding (stops for a group the moment its regrowth starts)
            if (mask != 0 && p.age % 3 == 0 && w.getTime() < BLEED_UNTIL.getOrDefault(p.getUuid(), 0L)) {
                for (Limb l : Limb.values()) {
                    if ((mask & l.bit()) != 0 && !regrowing(p.getUuid(), l.group)) {
                        Vec3d a = Anchors.top(body, l);
                        Fx.at(w, Fx.BLOOD, a, 3, 0.07, 0.01);
                        if (p.age % 6 == 0) Fx.at(w, Fx.BLOOD_CHUNK, a, 1, 0.05, 0.02);
                    }
                }
            }

            if (regs != null) tickRegen(p, w, body, regs);
        }
    }

    private static void pollHead(ServerPlayerEntity p) {
        if (p.isCreative() || p.isSpectator()) return;
        if (DaotBridge.isBeheaded(p)) { loseHead(p); return; }
        if (LimbConfig.KILL_SHIFTER_WHEN_TITAN_BEHEADED) {
            Entity t = DaotBridge.ridingTitan(p);
            if (t != null && DaotBridge.isBeheaded(t)) loseHead(p);
        }
    }

    private static void tickRegen(ServerPlayerEntity p, ServerWorld w, Entity body, List<Regen> regs) {
        Iterator<Regen> it = regs.iterator();
        while (it.hasNext()) {
            Regen r = it.next();
            r.age++;
            int total = r.group == Limb.Group.EYES
                    ? LimbConfig.EYE_REGEN_TICKS
                    : LimbConfig.REGEN_SMOKE + LimbConfig.REGEN_BONE + LimbConfig.REGEN_FLESH + LimbConfig.REGEN_SKIN;

            if (r.age % 2 == 0) {
                for (Limb l : Limb.values()) {
                    if ((r.mask & l.bit()) == 0) continue;
                    Vec3d top = Anchors.top(body, l);
                    if (r.steam) Fx.smoke(w, top, 2, 0.12);           // DAOT steam (bandages have none)
                    if (r.group == Limb.Group.EYES) {
                        double er = (r.age - 20) / (double) (total - 20);       // the black patch washes away top to bottom
                        if (er > 0) syncGrow(p, l, (float) Math.min(1.0, er));
                        continue;
                    }

                    int a = r.age - LimbConfig.REGEN_SMOKE;
                    if (a < 0) continue;                               // steam-only phase
                    if (a < LimbConfig.REGEN_BONE) {                   // white stick (bone) grows
                        LimbVisuals.show(p.getUuid(), w, body, l, 1, a / (double) LimbConfig.REGEN_BONE);
                    } else if (a < LimbConfig.REGEN_BONE + LimbConfig.REGEN_FLESH) {   // red flesh grows around it
                        LimbVisuals.show(p.getUuid(), w, body, l, 2, (a - LimbConfig.REGEN_BONE) / (double) LimbConfig.REGEN_FLESH);
                    } else {                                           // skin colour closes over
                        double skin = (a - LimbConfig.REGEN_BONE - LimbConfig.REGEN_FLESH) / (double) LimbConfig.REGEN_SKIN;
                        LimbVisuals.show(p.getUuid(), w, body, l, 3, skin);
                        syncGrow(p, l, (float) Math.max(0.02, Math.min(1.0, skin)));   // your real skin grows back
                    }
                }
            }

            if (r.age >= total) {
                LimbVisuals.clear(p.getUuid(), r.mask);
                restore(p, r.mask);
                for (Limb l : Limb.values()) {
                    if ((r.mask & l.bit()) != 0) {
                        Vec3d a = Anchors.top(body, l);
                        if (r.group == Limb.Group.EYES) Fx.at(w, net.minecraft.particle.ParticleTypes.FLASH, a, 1, 0, 0);
                        if (r.steam) Fx.smoke(w, a, 14, 0.2);
                    }
                }
                w.playSound(null, p.getX(), p.getY(), p.getZ(), (r.steam ? SoundEvents.ENTITY_FIREWORK_ROCKET_BLAST : SoundEvents.BLOCK_WOOL_PLACE), SoundCategory.PLAYERS, 1.2f, 0.8f);
                p.sendMessage(Text.literal(r.group == Limb.Group.EYES ? "You can see again." : "Your " + Limb.describe(r.mask) + " regrew.").formatted(Formatting.GREEN), true);
                it.remove();
            }
        }
    }

    // =====================================================================================
    //  Gameplay effects of missing limbs (attribute modifiers: no potion icons, saved nowhere, re-applied each 40 ticks)
    // =====================================================================================

    public static int armLegLost(ServerPlayerEntity p) {
        return LimbData.get(p) & (Limb.maskOf(Limb.Group.ARM) | Limb.maskOf(Limb.Group.LEG));
    }

    private static int count(int mask, Limb.Group g) {
        return Integer.bitCount(mask & Limb.maskOf(g));
    }

    public static void applyEffects(ServerPlayerEntity p) {
        int mask = LimbData.get(p);
        int arms = count(mask, Limb.Group.ARM);
        int legs = count(mask, Limb.Group.LEG);
        if (mask != 0) EFFECTS_APPLIED.add(p.getUuid());

        // one leg: slower walking (ODM / gas flight is not touched). two legs: cannot walk or jump at all.
        double speed = legs == 0 ? 0 : (legs == 1 ? LimbConfig.ONE_LEG_SPEED : -1.0);
        double jump = legs >= 2 ? -1.0 : 0;

        mod(p, EntityAttributes.GENERIC_MOVEMENT_SPEED, "legs_speed", speed);
        mod(p, EntityAttributes.GENERIC_JUMP_STRENGTH, "legs_jump", jump);
        mod(p, EntityAttributes.GENERIC_ATTACK_DAMAGE, "arms_damage", -0.4 * arms);
        mod(p, EntityAttributes.PLAYER_BLOCK_BREAK_SPEED, "arms_mining", arms >= 2 ? -1.0 : -0.4 * arms);   // both arms gone = cannot break blocks
        swimPenalty(p, mask);

        Entity titan = DaotBridge.ridingTitan(p);
        if (titan instanceof LivingEntity t) {
            mod(t, EntityAttributes.GENERIC_MOVEMENT_SPEED, "legs_speed", speed);
        }
        if (titan != null) {
            if (legs >= 2) {
                DaotBridge.setTitanLegsShattered(titan, true);
                SHATTERED_BY_US.add(titan.getUuid());
            } else if (SHATTERED_BY_US.remove(titan.getUuid())) {
                DaotBridge.setTitanLegsShattered(titan, false);
            }
        }
    }

    public static boolean bothArmsGone(ServerPlayerEntity p) {
        return Integer.bitCount(LimbData.get(p) & Limb.maskOf(Limb.Group.ARM)) >= 2;
    }

    /**
     * Swimming: missing arms slow you in the water; with ONE leg gone the slowdown doubles;
     * with BOTH legs gone you cannot swim at all (and you sink). Only applies while you are in water.
     */
    private static void swimPenalty(ServerPlayerEntity p, int mask) {
        int arms = count(mask, Limb.Group.ARM);
        int legs = count(mask, Limb.Group.LEG);
        double pen = 0;
        if (p.isTouchingWater()) {
            pen = LimbConfig.SWIM_ARM_PENALTY * arms;
            if (legs == 1) pen = Math.min(0.9, (pen + 0.15) * 2.0);
            else if (legs >= 2) pen = 1.0;
        }
        mod(p, EntityAttributes.GENERIC_MOVEMENT_SPEED, "swim_penalty", -pen);
    }

    // ---- arms: no right arm = nothing in the main hand, no left arm = nothing in the off-hand ----
    private static void enforceArms(ServerPlayerEntity p, int mask) {
        if (p.isCreative() || p.isSpectator()) return;
        boolean dropped = false;
        if ((mask & Limb.RIGHT_ARM.bit()) != 0 && LimbConfig.RIGHT_ARM_BLOCKS_MAINHAND) {
            if (dropHand(p, Hand.MAIN_HAND)) dropped = true;
        }
        if ((mask & Limb.LEFT_ARM.bit()) != 0 && LimbConfig.LEFT_ARM_BLOCKS_OFFHAND) {
            if (dropHand(p, Hand.OFF_HAND)) dropped = true;
        }
        if (dropped) p.sendMessage(Text.literal("You can't hold that without your arm!").formatted(Formatting.RED), true);
    }

    private static void mod(LivingEntity p, RegistryEntry<EntityAttribute> attr, String name, double value) {
        EntityAttributeInstance inst = p.getAttributeInstance(attr);
        if (inst == null) return;
        Identifier id = Identifier.of(DaotLimbs.MOD_ID, name);
        EntityAttributeModifier cur = inst.getModifier(id);
        if (value == 0) { if (cur != null) inst.removeModifier(id); return; }
        if (cur != null && cur.value() == value) return;
        if (cur != null) inst.removeModifier(id);
        inst.addTemporaryModifier(new EntityAttributeModifier(id, value, EntityAttributeModifier.Operation.ADD_MULTIPLIED_TOTAL));
    }

    // =====================================================================================
    //  Helpers / sync / cleanup
    // =====================================================================================

    /** The entity limb effects should appear on: the titan body when in titan form, else the player. */
    public static Entity bodyOf(ServerPlayerEntity p) {
        Entity t = DaotBridge.ridingTitan(p);
        return t != null ? t : p;
    }

    // ---------- falling ----------

    /**
     * 2 = lying flat, 1 = pushed up onto the knees, 0 = standing.
     * Both legs gone = down for good; losing any leg knocks you down for a moment.
     * While legs regrow they lift you: flat first, onto your knees halfway, standing once the skin is growing over.
     */
    private static int fallLevel(ServerPlayerEntity p, int mask) {
        if (p.hasVehicle()) return 0;
        boolean down = Integer.bitCount(mask & Limb.maskOf(Limb.Group.LEG)) >= 2
                || p.getServerWorld().getTime() < FALLEN_UNTIL.getOrDefault(p.getUuid(), 0L);
        if (!down) return 0;
        List<Regen> regs = REGEN.get(p.getUuid());
        if (regs != null) {
            for (Regen r : regs) {
                if (r.group != Limb.Group.LEG) continue;
                int total = LimbConfig.REGEN_SMOKE + LimbConfig.REGEN_BONE + LimbConfig.REGEN_FLESH + LimbConfig.REGEN_SKIN;
                double f = r.age / (double) total;
                if (f >= 0.78) return 0;
                if (f >= 0.5) return 1;
                break;
            }
        }
        return 2;
    }

    private static boolean legsRegrowing(ServerPlayerEntity p) {
        return regrowing(p.getUuid(), Limb.Group.LEG);
    }

    public static boolean isFallenNow(ServerPlayerEntity p) {
        return FALL_LEVEL.getOrDefault(p.getUuid(), 0) == 2;
    }

    /** The mask clients receive: lost limbs plus the transient lying / kneeling bits. */
    public static int syncMask(ServerPlayerEntity p) {
        int lvl = FALL_LEVEL.getOrDefault(p.getUuid(), 0);
        return LimbData.get(p) | (lvl == 2 ? LimbRules.FALLEN_BIT : (lvl == 1 ? LimbRules.KNEEL_BIT : 0));
    }

    private static void syncGrow(ServerPlayerEntity p, Limb l, float progress) {
        LimbNet.GrowPayload pl = new LimbNet.GrowPayload(p.getId(), l.ordinal(), progress);
        ServerPlayNetworking.send(p, pl);
        for (ServerPlayerEntity o : PlayerLookup.tracking(p)) ServerPlayNetworking.send(o, pl);
    }

    public static void sync(ServerPlayerEntity p) {
        LimbNet.SyncPayload pl = new LimbNet.SyncPayload(p.getId(), syncMask(p));
        ServerPlayNetworking.send(p, pl);
        for (ServerPlayerEntity o : PlayerLookup.tracking(p)) ServerPlayNetworking.send(o, pl);
        sendSpots(p, p);
        for (ServerPlayerEntity o : PlayerLookup.tracking(p)) sendSpots(p, o);
    }

    /** Tells `viewer` where `owner`'s hollow eyes sit. */
    public static void sendSpots(ServerPlayerEntity owner, ServerPlayerEntity viewer) {
        int[] sp = LimbData.spots(owner);
        ServerPlayNetworking.send(viewer, new LimbNet.SpotsPayload(owner.getId(), sp[0], sp[1], sp[2], sp[3]));
    }

    /** The player tapped the face: that eye's hollow goes there, the other eye is mirrored. */
    public static void setEyeSpot(ServerPlayerEntity p, int limbOrdinal, int x10, int y10) {
        if (limbOrdinal != Limb.LEFT_EYE.ordinal() && limbOrdinal != Limb.RIGHT_EYE.ordinal()) return;
        if ((LimbData.get(p) & (1 << limbOrdinal)) == 0) return;               // that eye must actually be lost
        int x = Math.max(10, Math.min(70, x10));
        int y = Math.max(10, Math.min(70, y10));
        int[] sp = LimbData.spots(p);
        boolean left = limbOrdinal == Limb.LEFT_EYE.ordinal();
        if (left) { sp[0] = x; sp[1] = y; sp[2] = 80 - x; sp[3] = y; }
        else      { sp[2] = x; sp[3] = y; sp[0] = 80 - x; sp[1] = y; }
        sp[4] = 1;
        LimbData.setSpots(p, sp);
        sync(p);
    }

    public static void onDeath(ServerPlayerEntity p) {
        LimbVisuals.clear(p.getUuid());
        HEALING.remove(p.getUuid());
        FALLEN_UNTIL.remove(p.getUuid());
        FALL_LEVEL.remove(p.getUuid());
        REGEN.remove(p.getUuid());
        BLEED_UNTIL.remove(p.getUuid());
        LAST_LOSS.remove(p.getUuid());
        EFFECTS_APPLIED.remove(p.getUuid());
    }

    public static void onDisconnect(UUID id) {
        LimbVisuals.clear(id);
        HEALING.remove(id);
        FALLEN_UNTIL.remove(id);
        FALL_LEVEL.remove(id);
        REGEN.remove(id);
        BLEED_UNTIL.remove(id);
        LAST_LOSS.remove(id);
        EFFECTS_APPLIED.remove(id);
    }

    /** Where on a body each limb sits (works for a 1.8 m player and for a 15 m titan alike). */
    public static final class Anchors {
        private Anchors() {}

        private static double scale(Entity e) { return e.getHeight() / 1.8; }

        public static Vec3d top(Entity e, Limb l) {
            double h = e.getHeight();
            double s = scale(e);
            double yaw = Math.toRadians(e instanceof LivingEntity le ? le.bodyYaw : e.getYaw());
            double side = l.isLeft() ? 1 : -1;                // entity's left = (cos yaw, sin yaw)
            double off = switch (l.group) { case ARM -> 0.37 * s; case LEG -> 0.13 * s; case EYES -> 0.10 * s; };
            double y = switch (l.group) { case ARM -> h * 0.80; case LEG -> h * 0.42; case EYES -> h * 0.90; };
            double fwd = l.group == Limb.Group.EYES ? 0.25 * s : 0;   // eyes are on the front of the head
            return new Vec3d(
                    e.getX() + Math.cos(yaw) * off * side - Math.sin(yaw) * fwd,
                    e.getY() + y,
                    e.getZ() + Math.sin(yaw) * off * side + Math.cos(yaw) * fwd);
        }

        public static double length(Entity e, Limb l) {
            double s = scale(e);
            return l.group == Limb.Group.LEG ? 0.75 * s : 0.7 * s;
        }
    }
}
