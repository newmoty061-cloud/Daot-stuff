package dev.daotlimbs.scout;

import dev.daotlimbs.FirstSpawn;
import dev.daotlimbs.LimbConfig;
import net.minecraft.entity.SpawnReason;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.Heightmap;

import java.util.List;

/** Keeps a few scouts walking around each player, in the Paradise dimension ONLY. */
public final class ScoutSpawner {
    private ScoutSpawner() {}

    public static void tick(MinecraftServer server) {
        if (server.getTicks() % 100 != 0 || ScoutEntity.TYPE == null) return;
        for (ServerWorld w : server.getWorlds()) {
            if (!w.getRegistryKey().getValue().equals(FirstSpawn.PARADIS)) continue;      // Paradise only
            for (ServerPlayerEntity p : w.getPlayers()) {
                if (p.isSpectator()) continue;
                List<ScoutEntity> near = w.getEntitiesByType(ScoutEntity.TYPE, p.getBoundingBox().expand(64), e -> true);
                if (near.size() >= LimbConfig.SCOUT_MAX_NEAR) continue;
                if (p.getRandom().nextInt(LimbConfig.SCOUT_SPAWN_CHANCE) != 0) continue;
                spawnNear(w, p);
            }
        }
    }

    private static void spawnNear(ServerWorld w, ServerPlayerEntity p) {
        var r = p.getRandom();
        double ang = r.nextDouble() * Math.PI * 2;
        double dist = 24 + r.nextDouble() * 16;
        int x = (int) Math.floor(p.getX() + Math.cos(ang) * dist);
        int z = (int) Math.floor(p.getZ() + Math.sin(ang) * dist);
        if (!w.isChunkLoaded(x >> 4, z >> 4)) return;
        int y = w.getTopY(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, x, z);
        BlockPos pos = new BlockPos(x, y, z);
        if (!w.getBlockState(pos.down()).isSolidBlock(w, pos.down()) || !w.getFluidState(pos).isEmpty()) return;

        ScoutEntity e = ScoutEntity.TYPE.create(w);
        if (e == null) return;
        e.refreshPositionAndAngles(x + 0.5, y, z + 0.5, r.nextFloat() * 360f, 0f);
        e.initialize(w, w.getLocalDifficulty(pos), SpawnReason.NATURAL, null);
        w.spawnEntityAndPassengers(e);
    }
}
