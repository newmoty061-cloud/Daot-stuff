package dev.daotlimbs.scout;

import dev.daotlimbs.DaotBridge;
import dev.daotlimbs.DaotLimbs;
import net.minecraft.entity.EntityData;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.ai.goal.FleeEntityGoal;
import net.minecraft.entity.ai.goal.LookAroundGoal;
import net.minecraft.entity.ai.goal.LookAtEntityGoal;
import net.minecraft.entity.ai.goal.SwimGoal;
import net.minecraft.entity.ai.goal.WanderAroundFarGoal;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.mob.PathAwareEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.world.LocalDifficulty;
import net.minecraft.world.ServerWorldAccess;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

import java.util.List;

/**
 * A scout of one of the three regiments. 300 skins (100 per regiment), a random personality and name,
 * and they talk to nearby players. Only ever spawned in Paradise (see ScoutSpawner).
 */
public class ScoutEntity extends PathAwareEntity {
    public static EntityType<ScoutEntity> TYPE;

    private static final TrackedData<Integer> VARIANT = DataTracker.registerData(ScoutEntity.class, TrackedDataHandlerRegistry.INTEGER);
    private static final TrackedData<Integer> PERSONALITY = DataTracker.registerData(ScoutEntity.class, TrackedDataHandlerRegistry.INTEGER);
    private static final TrackedData<Integer> BLOODLINE = DataTracker.registerData(ScoutEntity.class, TrackedDataHandlerRegistry.INTEGER);

    private int ambientCooldown = 100;
    private int alarmCooldown = 0;

    public ScoutEntity(EntityType<? extends ScoutEntity> type, World world) {
        super(type, world);
    }

    @Override
    protected void initDataTracker(DataTracker.Builder builder) {
        super.initDataTracker(builder);
        builder.add(VARIANT, 0);
        builder.add(PERSONALITY, 0);
        builder.add(BLOODLINE, 0);
    }

    public static DefaultAttributeContainer.Builder createAttributes() {
        return PathAwareEntity.createMobAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 20.0)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.26)
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 24.0);
    }

    @Override
    protected void initGoals() {
        this.goalSelector.add(0, new SwimGoal(this));
        this.goalSelector.add(1, new FleeEntityGoal<>(this, HostileEntity.class, 14.0f, 1.0, 1.35));
        this.goalSelector.add(5, new WanderAroundFarGoal(this, 0.8));
        this.goalSelector.add(6, new LookAtEntityGoal(this, PlayerEntity.class, 8.0f));
        this.goalSelector.add(7, new LookAroundGoal(this));
    }

    @Override
    public EntityData initialize(ServerWorldAccess world, LocalDifficulty difficulty, SpawnReason spawnReason, @Nullable EntityData entityData) {
        EntityData data = super.initialize(world, difficulty, spawnReason, entityData);
        int reg = this.random.nextInt(3);
        int design = this.random.nextInt(100);
        this.dataTracker.set(VARIANT, reg * 100 + design);
        this.dataTracker.set(PERSONALITY, this.random.nextInt(ScoutDialogue.Personality.values().length));
        this.setCustomName(Text.literal(ScoutDialogue.randomName(this.random)));
        this.setPersistent();
        this.setCanPickUpLoot(false);                       // scouts never carry ODM gear or blades

        ScoutDialogue.Bloodline blood = ScoutDialogue.Bloodline.roll(this.random);
        this.dataTracker.set(BLOODLINE, blood.ordinal());
        if (blood == ScoutDialogue.Bloodline.ACKERMAN) {
            this.getAttributeInstance(EntityAttributes.GENERIC_MAX_HEALTH).setBaseValue(30.0);
            this.getAttributeInstance(EntityAttributes.GENERIC_MOVEMENT_SPEED).setBaseValue(0.34);
        } else if (blood == ScoutDialogue.Bloodline.ROYAL) {
            this.getAttributeInstance(EntityAttributes.GENERIC_MAX_HEALTH).setBaseValue(24.0);
        }
        this.setHealth(this.getMaxHealth());
        return data;
    }

    public int getVariant() { return this.dataTracker.get(VARIANT); }

    public ScoutDialogue.Regiment getRegiment() {
        return ScoutDialogue.Regiment.values()[Math.max(0, Math.min(2, getVariant() / 100))];
    }

    public ScoutDialogue.Personality getPersonality() {
        ScoutDialogue.Personality[] all = ScoutDialogue.Personality.values();
        return all[Math.max(0, Math.min(all.length - 1, this.dataTracker.get(PERSONALITY)))];
    }

    public ScoutDialogue.Bloodline getBloodline() {
        ScoutDialogue.Bloodline[] all = ScoutDialogue.Bloodline.values();
        return all[Math.max(0, Math.min(all.length - 1, this.dataTracker.get(BLOODLINE)))];
    }

    /** texture for variant 0..299: three regiments x 100 designs */
    public static Identifier texture(int variant) {
        int v = Math.max(0, Math.min(299, variant));
        ScoutDialogue.Regiment reg = ScoutDialogue.Regiment.values()[v / 100];
        return Identifier.of(DaotLimbs.MOD_ID, String.format("textures/entity/scout/%s_%03d.png", reg.code, v % 100));
    }

    private static String capitalize(String s) {
        return s.isEmpty() ? s : s.charAt(0) + s.substring(1).toLowerCase();
    }

    private String nameText() {
        return this.hasCustomName() ? this.getCustomName().getString() : "Scout";
    }

    private void speakNearby(String line, double range) {
        for (PlayerEntity pl : this.getWorld().getPlayers()) {
            if (pl instanceof ServerPlayerEntity sp && sp.squaredDistanceTo(this) <= range * range) {
                ScoutDialogue.say(nameText(), getRegiment(), sp, line);
            }
        }
    }

    @Override
    public ActionResult interactMob(PlayerEntity player, Hand hand) {
        if (!this.getWorld().isClient && player instanceof ServerPlayerEntity sp) {
            if (player.isSneaking()) {      // sneak + use: who is this?
                sp.sendMessage(Text.literal(nameText() + " - " + getRegiment().title + " - " + capitalize(getPersonality().name())
                        + " - " + getBloodline().title + " blood"), false);
            } else {
                ScoutDialogue.say(nameText(), getRegiment(), sp, ScoutDialogue.chatLine(getRegiment(), getPersonality(), getBloodline(), this.random));
            }
            this.getLookControl().lookAt(player);
        }
        return ActionResult.success(this.getWorld().isClient);
    }

    @Override
    public void tick() {
        super.tick();
        if (this.getWorld().isClient || this.age % 20 != 0) return;

        if (alarmCooldown > 0) alarmCooldown -= 20;
        if (alarmCooldown <= 0) {
            List<LivingEntity> titans = this.getWorld().getEntitiesByClass(LivingEntity.class, this.getBoundingBox().expand(22),
                    e -> e.isAlive() && (DaotBridge.isPureTitan(e) || DaotBridge.isShifterTitan(e)));
            if (!titans.isEmpty()) {
                speakNearby(ScoutDialogue.alarmLine(getPersonality(), this.random), 24);
                alarmCooldown = 400;
                return;
            }
        }

        ambientCooldown -= 20;
        if (ambientCooldown <= 0) {
            PlayerEntity near = this.getWorld().getClosestPlayer(this, 8.0);
            if (near instanceof ServerPlayerEntity sp) {
                ScoutDialogue.say(nameText(), getRegiment(), sp, ScoutDialogue.chatLine(getRegiment(), getPersonality(), getBloodline(), this.random));
            }
            ambientCooldown = 300 + this.random.nextInt(500);
        }
    }

    @Override
    public void writeCustomDataToNbt(NbtCompound nbt) {
        super.writeCustomDataToNbt(nbt);
        nbt.putInt("ScoutVariant", getVariant());
        nbt.putInt("ScoutPersonality", this.dataTracker.get(PERSONALITY));
        nbt.putInt("ScoutBloodline", this.dataTracker.get(BLOODLINE));
    }

    @Override
    public void readCustomDataFromNbt(NbtCompound nbt) {
        super.readCustomDataFromNbt(nbt);
        this.dataTracker.set(VARIANT, nbt.getInt("ScoutVariant"));
        this.dataTracker.set(PERSONALITY, nbt.getInt("ScoutPersonality"));
        this.dataTracker.set(BLOODLINE, nbt.getInt("ScoutBloodline"));
    }

    @Override
    public boolean canImmediatelyDespawn(double distanceSquared) { return false; }
}
