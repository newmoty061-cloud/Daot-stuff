package dev.daotlimbs.scout;

import dev.daotlimbs.DaotLimbs;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public final class LimbEntities {
    private LimbEntities() {}

    public static void register() {
        ScoutEntity.TYPE = Registry.register(Registries.ENTITY_TYPE, Identifier.of(DaotLimbs.MOD_ID, "scout"),
                EntityType.Builder.create(ScoutEntity::new, SpawnGroup.CREATURE)
                        .dimensions(0.6f, 1.8f)
                        .maxTrackingRange(10)
                        .build("scout"));
        FabricDefaultAttributeRegistry.register(ScoutEntity.TYPE, ScoutEntity.createAttributes());
    }
}
