package dev.daotlimbs;

import net.minecraft.entity.Entity;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Hold Shift for 5 seconds while in a titan: the titan smokes and disappears and you climb out.
 * Before the 5 seconds are up nothing happens (no smoke, the titan stays).
 */
public final class TitanEscape {
    private TitanEscape() {}

    private static final Map<UUID, Integer> HELD = new HashMap<>();

    private static final Map<UUID, Integer> LAST_EJECT = new HashMap<>();

    /** Pressing E inside a Colossal Titan: a big cloud of smoke and you are thrown out of the body. */
    public static void eject(ServerPlayerEntity p) {
        Entity t = DaotBridge.titanOf(p);
        if (t == null || !DaotBridge.isColossal(t)) return;
        if (p.age - LAST_EJECT.getOrDefault(p.getUuid(), -1000) < 40) return;
        LAST_EJECT.put(p.getUuid(), p.age);

        HoldGate.allow(p);
        boolean ok = DaotBridge.triggerTitanShift(p);
        HoldGate.clear(p);
        if (!ok) ok = DaotBridge.releaseTitans(p);
        if (t.getWorld() instanceof ServerWorld w) {
            for (int i = 0; i < 3; i++) Fx.bodySteam(w, t, LimbConfig.ESCAPE_STEAM_PER_BURST * 2);   // lots of smoke
        }
        p.sendMessage(Text.literal(ok ? "You burst out of your titan!" : "Could not leave the titan (see log).").formatted(Formatting.WHITE), true);
    }

    public static void tick(MinecraftServer server) {
        for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
            if (!p.isSneaking()) { HELD.remove(p.getUuid()); continue; }
            Entity t = DaotBridge.titanOf(p);
            if (t == null) { HELD.remove(p.getUuid()); continue; }

            int held = HELD.merge(p.getUuid(), 1, Integer::sum);
            if (held > LimbConfig.RELEASE_HOLD_TICKS) continue;       // already triggered; wait for Shift to be released

            if (held % 20 == 0 && held < LimbConfig.RELEASE_HOLD_TICKS) {
                int secs = held / 20, total = LimbConfig.RELEASE_HOLD_TICKS / 20;
                p.sendMessage(Text.literal("Leaving your titan... " + secs + "/" + total).formatted(Formatting.GRAY), true);
            }
            if (held == LimbConfig.RELEASE_HOLD_TICKS) {
                HoldGate.allow(p);
                boolean ok = DaotBridge.triggerTitanShift(p);
                HoldGate.clear(p);
                if (!ok) ok = DaotBridge.releaseTitans(p);
                if (t.getWorld() instanceof ServerWorld w && DaotBridge.isColossal(t)) {
                    Fx.bodySteam(w, t, LimbConfig.ESCAPE_STEAM_PER_BURST * 2);
                }
                p.sendMessage(Text.literal(ok ? "Your titan wastes away..." : "Could not leave the titan (see log).").formatted(Formatting.WHITE), true);
            }
        }
    }
}
