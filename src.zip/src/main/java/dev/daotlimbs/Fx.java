package dev.daotlimbs;

import net.minecraft.block.Blocks;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.Box;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.particle.BlockStateParticleEffect;
import net.minecraft.particle.DustParticleEffect;
import net.minecraft.particle.ItemStackParticleEffect;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.particle.SimpleParticleType;
import net.minecraft.registry.Registries;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;
import org.joml.Vector3f;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

/** Particle helpers. Created lazily so registries are ready. */
public final class Fx {
    private Fx() {}

    public static final ParticleEffect BLOOD = new DustParticleEffect(new Vector3f(0.62f, 0.02f, 0.02f), 1.3f);
    public static final ParticleEffect BLOOD_CHUNK = new BlockStateParticleEffect(ParticleTypes.BLOCK, Blocks.REDSTONE_BLOCK.getDefaultState());
    public static final ParticleEffect FLESH = new DustParticleEffect(new Vector3f(0.80f, 0.20f, 0.22f), 1.4f);
    public static final ParticleEffect SKIN = new DustParticleEffect(new Vector3f(0.96f, 0.78f, 0.62f), 1.2f);
    public static final ParticleEffect BONE = new ItemStackParticleEffect(ParticleTypes.ITEM, new ItemStack(Items.BONE_MEAL));

    private static final Map<String, ParticleEffect> DAOT_CACHE = new HashMap<>();
    private static final Map<String, ParticleEffect> BITS_CACHE = new HashMap<>();

    /** Crumbling-block particles that use the block's own texture (our flesh / bone / skin blocks). */
    public static ParticleEffect bits(net.minecraft.block.Block block) {
        String key = Registries.BLOCK.getId(block).toString();
        return BITS_CACHE.computeIfAbsent(key, k -> new BlockStateParticleEffect(ParticleTypes.BLOCK, block.getDefaultState()));
    }

    /** One of Danny's AOT's own particle types (e.g. "nape_steam"), or the fallback if it can't be found. */
    public static ParticleEffect daot(String path, ParticleEffect fallback) {
        ParticleEffect cached = DAOT_CACHE.get(path);
        if (cached != null) return cached;
        ParticleEffect result = fallback;
        Optional<?> type = Registries.PARTICLE_TYPE.getOrEmpty(Identifier.of("dannys-aot", path));
        if (type.isPresent() && type.get() instanceof SimpleParticleType simple) result = simple;
        DAOT_CACHE.put(path, result);
        return result;
    }

    /** The steam you see coming off a titan's nape / healing wounds in DAOT. */
    public static ParticleEffect steam() { return daot("nape_steam", ParticleTypes.LARGE_SMOKE); }

    /** The big billowing steam the Colossal gives off. */
    public static ParticleEffect bigSteam() { return daot("colossal_steam", ParticleTypes.CAMPFIRE_COSY_SMOKE); }

    public static void at(ServerWorld w, ParticleEffect fx, Vec3d p, int count, double spread, double speed) {
        w.spawnParticles(fx, p.x, p.y, p.z, count, spread, spread, spread, speed);
    }

    /** For huge things (titans): forced, visible from far away. */
    public static void far(ServerWorld w, ParticleEffect fx, Vec3d p, int count, double spread, double speed) {
        for (ServerPlayerEntity v : w.getPlayers()) {
            if (v.squaredDistanceTo(p) < 192 * 192) {
                w.spawnParticles(v, fx, true, p.x, p.y, p.z, count, spread, spread, spread, speed);
            }
        }
    }

    public static final ParticleEffect WHITE_PUFF = new DustParticleEffect(new Vector3f(1f, 1f, 1f), 4.0f);

    /** One forced particle that drifts with the given velocity (count 0 = the offsets are the velocity). */
    public static void drift(ServerWorld w, ParticleEffect fx, Vec3d p, Vec3d v) {
        for (ServerPlayerEntity viewer : w.getPlayers()) {
            if (viewer.squaredDistanceTo(p) < 192 * 192) {
                w.spawnParticles(viewer, fx, true, p.x, p.y, p.z, 0, v.x, v.y, v.z, 1.0);
            }
        }
    }

    /**
     * Thick WHITE steam that pours off the surface of a big body (the Colossal): from its sides, drifting outward and
     * up, with extra vents from the head and shoulders.
     */
    public static void bodySteam(ServerWorld w, Entity e, int count) {
        Box b = e.getBoundingBox();
        var r = w.getRandom();
        Vec3d c = b.getCenter();
        double rx = b.getLengthX() * 0.5, rz = b.getLengthZ() * 0.5, h = b.getLengthY();
        for (int i = 0; i < count; i++) {
            double th = r.nextDouble() * Math.PI * 2;
            double k = 0.85 + 0.15 * r.nextDouble();                    // on the surface, not inside it
            double y = b.minY + r.nextDouble() * h * 0.95;
            if (r.nextInt(5) == 0) {                                    // vents at the head / shoulders
                y = b.maxY - r.nextDouble() * h * 0.08;
                k = 0.3 * r.nextDouble();
            }
            Vec3d p = new Vec3d(c.x + Math.cos(th) * rx * k, y, c.z + Math.sin(th) * rz * k);
            Vec3d v = new Vec3d(Math.cos(th) * 0.04, 0.05 + r.nextDouble() * 0.12, Math.sin(th) * 0.04);
            drift(w, (i % 2 == 0) ? ParticleTypes.CLOUD : WHITE_PUFF, p, v);
        }
    }

    /** Healing steam (DAOT's own look). */
    public static void smoke(ServerWorld w, Vec3d p, int count, double spread) {
        at(w, steam(), p, count, spread, 0.02);
    }
}
