package dev.daotlimbs;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.block.BlockState;
import net.minecraft.entity.Entity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.Vec3d;

import java.lang.reflect.Field;
import java.util.*;

/**
 * Beast Titan in an ice biome:
 *  - it can pick up rocks from snow / ice ground (DAOT only allows stone ground), and the rock it throws is an ICE boulder
 *    that hits for less than a stone;
 *  - the "carry" ability (#2) holds ice that melts to steam after 2 seconds, with no water left behind.
 */
public final class IceRocks {
    private IceRocks() {}

    public static final String TAG = "daot_limbs_ice";
    /** guards the damage re-application in the damage event */
    public static boolean reapplying = false;

    private static final class Ice {
        Entity anchor;                // the thrown rock or the carrying titan
        List<Entity> parts = new ArrayList<>();
        int ticksLeft = -1;           // >= 0: carried ice melting
        double scale;
    }

    private static final List<Entity> ROCKS = new ArrayList<>();
    private static final Map<UUID, Ice> THROWN = new HashMap<>();
    private static final Map<UUID, Ice> CARRIED = new HashMap<>();
    private static Field ownerField;

    public static void init() {
        ServerEntityEvents.ENTITY_LOAD.register((e, w) -> {
            if (e.getClass().getSimpleName().equals("RockProjectileEntity")) ROCKS.add(e);
        });
        ServerTickEvents.END_SERVER_TICK.register(IceRocks::tick);
    }

    // ------------------------------------------------------------------ helpers used by the Beast mixin

    public static boolean isIceGround(BlockState s) {
        return s.isIn(BlockTags.ICE) || s.isIn(BlockTags.SNOW);
    }

    public static boolean isIceBiome(Entity e) {
        return e.getWorld().getBiome(e.getBlockPos()).value().getTemperature() <= LimbConfig.ICE_TEMPERATURE_MAX;
    }

    /** Beast Titan used its carry ability: hold ice for 2 seconds, then it melts. */
    public static void onCarryAbility(Entity titan) {
        if (!(titan.getWorld() instanceof ServerWorld w) || !isIceBiome(titan)) return;
        Ice old = CARRIED.remove(titan.getUuid());
        if (old != null) LimbVisuals.discardAll(old.parts);
        Ice ice = new Ice();
        ice.anchor = titan;
        ice.scale = Math.max(1.0, titan.getHeight() / 8.0);
        ice.ticksLeft = LimbConfig.ICE_MELT_TICKS;
        ice.parts = TitanModels.spawnAt(w, handPos(titan, ice.scale), 0f, "ice_rock", ice.scale, 2);
        CARRIED.put(titan.getUuid(), ice);
    }

    private static Vec3d handPos(Entity titan, double scale) {
        float yaw = titan instanceof net.minecraft.entity.LivingEntity le ? le.bodyYaw : titan.getYaw();
        double rad = Math.toRadians(yaw);
        double fwd = 1.6 * scale;
        return new Vec3d(titan.getX() - Math.sin(rad) * fwd, titan.getY() + titan.getHeight() * 0.5, titan.getZ() + Math.cos(rad) * fwd);
    }

    // ------------------------------------------------------------------ per tick

    private static void tick(MinecraftServer server) {
        // thrown rocks: swap in the ice look the first tick we know who threw them
        Iterator<Entity> it = ROCKS.iterator();
        while (it.hasNext()) {
            Entity rock = it.next();
            if (rock.isRemoved()) {
                Ice ice = THROWN.remove(rock.getUuid());
                if (ice != null) LimbVisuals.discardAll(ice.parts);
                it.remove();
                continue;
            }
            if (!(rock.getWorld() instanceof ServerWorld w)) continue;
            Ice ice = THROWN.get(rock.getUuid());
            if (ice == null) {
                if (rock.age < 1) continue;
                UUID owner = ownerOf(rock);
                if (owner == null) continue;
                Entity thrower = w.getEntity(owner);
                if (thrower == null || !thrower.getClass().getSimpleName().equals("BeastTitanEntity") || !isIceBiome(thrower)) {
                    THROWN.put(rock.getUuid(), new Ice());          // not ice: remember so we do not check again
                    continue;
                }
                rock.addCommandTag(TAG);
                ice = new Ice();
                ice.anchor = rock;
                ice.scale = Math.max(0.8, rockScale(rock));
                ice.parts = TitanModels.spawnAt(w, rock.getPos(), 0f, "ice_rock", ice.scale * 1.15, 2);
                THROWN.put(rock.getUuid(), ice);
            }
            if (ice.anchor != null) {
                for (Entity p : ice.parts) p.refreshPositionAfterTeleport(rock.getX(), rock.getY(), rock.getZ());
                if (rock.age % 4 == 0) {
                    Fx.far(w, ParticleTypes.SNOWFLAKE, rock.getPos(), 3, 0.3 * ice.scale, 0.02);
                }
            }
        }

        // carried ice: follows the titan's hands, melts into smoke
        Iterator<Map.Entry<UUID, Ice>> ci = CARRIED.entrySet().iterator();
        while (ci.hasNext()) {
            Ice ice = ci.next().getValue();
            Entity titan = ice.anchor;
            if (titan == null || titan.isRemoved() || !(titan.getWorld() instanceof ServerWorld w)) {
                LimbVisuals.discardAll(ice.parts);
                ci.remove();
                continue;
            }
            Vec3d hand = handPos(titan, ice.scale);
            for (Entity p : ice.parts) p.refreshPositionAfterTeleport(hand.x, hand.y, hand.z);
            if (--ice.ticksLeft > 0) {
                if (ice.ticksLeft % 5 == 0) Fx.far(w, ParticleTypes.CLOUD, hand, 2, 0.4 * ice.scale, 0.01);   // starting to steam
                continue;
            }
            // melted: smoke, no water
            LimbVisuals.discardAll(ice.parts);
            Fx.far(w, ParticleTypes.CLOUD, hand, 30, 0.7 * ice.scale, 0.05);
            Fx.far(w, Fx.WHITE_PUFF, hand, 12, 0.6 * ice.scale, 0.02);
            Fx.far(w, Fx.steam(), hand, 12, 0.6 * ice.scale, 0.03);
            ServerPlayerEntity shifter = DaotBridge.shifterOf(titan, server);
            if (shifter != null) {
                shifter.sendMessage(Text.literal("It melted.").formatted(Formatting.AQUA), false);
                shifter.sendMessage(Text.literal("It melted.").formatted(Formatting.AQUA), true);
            }
            DaotBridge.cancelRockThrow(titan);
            ci.remove();
        }
    }

    private static UUID ownerOf(Entity rock) {
        try {
            if (ownerField == null) {
                ownerField = rock.getClass().getDeclaredField("ownerUUID");
                ownerField.setAccessible(true);
            }
            return (UUID) ownerField.get(rock);
        } catch (Throwable t) {
            DaotLimbs.LOGGER.warn("[daot_limbs] cannot read rock owner: {}", t.toString());
            return null;
        }
    }

    private static double rockScale(Entity rock) {
        try {
            return ((Number) rock.getClass().getMethod("getRockScale").invoke(rock)).doubleValue();
        } catch (Throwable t) { return 1.0; }
    }
}
